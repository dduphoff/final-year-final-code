#include"motors.h"
Serial pc(USBTX, USBRX);
Serial esp8266(D1,D0);
I2C    i2c(D4, D5);
MPU6050 MPU;
DigitalInOut oldtx(D13);
DigitalInOut oldrx(D12);
float roll, pitch , yaw, preyaw, dYaw;
//float rollset , pitchset, yawset;
double rollratio,pitchratio, Zangleratio;
char cmd[20];
float gravmag;
bool gravmag_broken = false;
float firstZaccel = 0;

int pitchP, pitchI, pitchD;
int rollP, rollI, rollD;
int yawP, yawI, yawD;
    
    //void calculatestabilizer(stabilizer s);
void cmd_exe(void){
    if(cmd[1]== '1'){
    //distance = ((10*cmd[3])-48)+(cmd[4]-48);
    spd = 10*(cmd[3]-48)+ (cmd[4]-48) ;
    //pc.printf(" pre map %d", spdset);
    spd = map(spd, 10, 99 , 1000 ,maxThrottle);
    }
    if(cmd[1]== '2'){
        //pc.printf("%s \n",cmd);
        Y = 10*(cmd[3]-48)+ (cmd[4]-48) ;
        Y = map(Y , 10,41,-15,15);
        pitchset = Y;
       //pc.printf("%d", pitchset);
        }
    if(cmd[1]== '3'){
      //  pc.printf("%s \n",cmd);
       //pc.printf("%s \n",cmd);
        X = 10*(cmd[3]-48)+ (cmd[4]-48) ;
        X = map(X , 10,41,-15,15);
        
        rollset= X;
     //pc.printf("%d\n", rollset);}
    if(cmd[1]== '4'){
       // pc.printf("%s \n",cmd);
        Z =  cmd[3];
        newZ = true;
        
        if (Z=='1'){Z=1;}
        if (Z=='-'){Z=-1;}
       // pc.printf("%d", Z);}
        }
    if(cmd[0]== 'P'){
        //pc.printf("%s \n",cmd);
    if (cmd[2] == 'P'){pitchP = (cmd[4]-48)*50; } // to tune pid from phone P.P=x;
    if (cmd[2] == 'I'){pitchI = (cmd[4]-48)*50; }
    if (cmd[2] == 'D'){pitchD = (cmd[4]-48)*50; }
    }
    
    if(cmd[0]== 'R'){
      //  pc.printf("%s \n",cmd);
    if (cmd[2] == 'P'){rollP = (cmd[4]-48)*50; } // to tune pid from phone P.P=x;
    if (cmd[2] == 'I'){rollI = (cmd[4]-48)*50; }
    if (cmd[2] == 'D'){rollD = (cmd[4]-48)*50; }
}
    if(cmd[0]== 'Y'){
       // pc.printf("%s \n",cmd);
    if (cmd[2] == 'P'){yawP = (cmd[4]-48)*10; } // to tune pid from phone P.P=x;
    if (cmd[2] == 'I'){yawI = (cmd[4]-48)*10; }
    if (cmd[2] == 'D'){yawD = (cmd[4]-48)*10; }
    
    
    
}
//pc.printf("roll= %d %d %d  pitch = %d %d %d  yaw %d %d %d  \n", rollP, rollI , rollD, pitchP, pitchI, pitchD, yawP, yawI, yawD);

}}
void calculateangle()  // calculateangle normal to gravity
{
  pitchratio = abs(gravmag)/abs(accelData[1]);
  pitch= 90 - (atan(pitchratio)* 180 / 3.14) ;
 // pitch =  (sin(pitch*(3.14/180))* (180 / 3.14));
  rollratio = abs(gravmag)/abs(accelData[0]);
  roll = 90 - (atan(rollratio)* 180 / 3.14) ;
  //roll =  (sin(roll*(3.14/180))* (180 / 3.14));
  Zangleratio= abs(accelData[2]) / gravmag ;
  Zangle = (acos(Zangleratio)* 180 / 3.1415);
 //pc.printf(" %f < - pitch roll-> %f   ",  pitch , roll);
//  pc.printf("  z angle = %f \n",Zangle);
//  if (accelData[0] > 0){pc.printf("roll = -%f ", roll);}
//  if (accelData[0] < 0){pc.printf("roll = %f ", roll);}
 //if (accelData[1] > 0){pc.printf("pitch = -%f\n", pitch);}
// if (accelData[1] < 0){pc.printf("pitch = %f \n", pitch);}
preyaw = yaw;

yaw = gyroData[2]/100;

dYaw = yaw - preyaw;
 
 }


void recalibrate()  // calibrate accelerometer to measure gravity vector outputs variables in approximate accelerations in ms-2
{
 
 int i = 0 ;
 accelData[2] = -accelData[2];
 
     Zaccel = (9.8*sin(accelData[2]/ gravmag)) +(9.8*sin(firstZaccel/ gravmag)) ;
     
    //pc.printf("%f\n",Zaccel);
     
       //
    // 
    // if((Zaccel> 9.8)&(gravmag_broken = false))
    // {
    //  maxZaccel = Zaccel;
   //   Zaccel =  map(Zaccel, minZaccel, maxZaccel , -9.8 , 9.8)  ;
      //   }
     
    // if((Zaccel > maxZaccel)& (gravmag_broken = true))
    // {
    // maxZaccel = Zaccel
    // maxZaccel = Zaccel;
     //Zaccel =  map(Zaccel, minZaccel, maxZaccel , -9.8 , 9.8)  ;
       //  }
     
     
     
     
     
     
     
     
     
     
     Yaccel = 9.8*(accelData[1]/ gravmag) ;
    // pc.printf("%f\n",Zaccel);  //
     Xaccel = 9.8*(accelData[0]/ gravmag) ;
     //pc.printf("%f\n",Zaccel);  //
     
    // accelData[2] -= 6;
   // pc.printf("%d;%d;%d;%d;%d;%d\n",accelData[0],accelData[1],accelData[2],gyroData[0],gyroData[1],gyroData[2]);
 }
 
 
 
 void spdUpdate()
 {
     spd1 = spd;
     spd2 = spd;
     spd3 = spd;
     spd4 = spd;
     
    
     if (accelData[0] < X){    // apply PID modifications to speed 
     
    // spd1 = spd - rollmod;//
     //spd2 = spd - rollmod;//
     spd3 = (spd + rollmod);//
     spd4 = (spd +rollmod);//
     
    }
      else {
     
     
     //spd3 = spd - rollmod;//
     //spd4 = spd -rollmod;//
     spd1 = (spd + rollmod);//
     spd2 = (spd + rollmod);//
     
     
    }
    
    
    
    if (accelData[1] < Y){
     //spd1 = spd1 - pitchmod;//
     //spd3 = spd3 - pitchmod;//
     spd2 = (spd2 + pitchmod);//
     spd4 = (spd4 + pitchmod);//
     
    }
      else {
     
     
     //spd2 = spd2 - pitchmod;//
     //spd4 = spd4 - pitchmod;//
     spd1 = (spd1 + pitchmod);//
     spd3 = (spd3 + pitchmod);//
     
    }
    if (gyroData[2] >= yaw)
    {
        spd1 = spd1 +yawmod;
        spd4= spd4 +yawmod;
        }
        else
    {
        
        spd2= spd2 +yawmod;
        spd3 = spd3 +yawmod;
        }
    
     
   
     if (spd1 > 2000){spd1=2000;}
      if (spd2 > 2000){spd2=2000;}
       if (spd3 > 2000){spd3=2000;}
        if (spd4 > 2000){spd4=2000;}
        
        if (spd == 1000)
       {
            spd1=1000;
           spd2=1000;
           spd3=1000;
           spd4=1000;
            
          }
        //pc.printf("%d",gyroData[2] );
       // spd1= map(spd1, 1000,2000, 0.0f, 1.0f);
         //spd2= map(spd2, 1000,2000, 0.0f, 1.0f);
          //spd3= map(spd3, 1000,2000, 0.0f, 1.0f);
          // spd4= map(spd4, 1000,2000, 0.0f, 1.0f);
         //  pc.printf("%f",spd1);
       // pc.printf("%d %d %d %d     rollset = %d   pitchset = %d\n",spd1, spd2, spd3, spd4, X, Y); 
     ESC1.pulsewidth_us(spd1); // write new speeds to motors
     ESC2.pulsewidth_us(spd2);
     ESC3.pulsewidth_us(spd3);
     ESC4.pulsewidth_us(spd4);
     
     
     
     
     }