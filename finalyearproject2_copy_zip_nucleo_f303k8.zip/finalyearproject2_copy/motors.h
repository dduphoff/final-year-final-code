#include "mbed.h"
#include "tuning.h"
PwmOut ESC1(D3);
PwmOut ESC2(D11);
PwmOut ESC3(D7);
PwmOut ESC4(D10);






float Serror;
float pitchmod, rollmod ,yawmod;
int pitchset= 0; 
int rollset = 0;
int yawset = 0;

struct stabilizer{
float setpoint; 
float input;
float output;
int Kp;
int Ki;
int Kd;
float previouserror;
    };








float Zangle;
float Zaccel;
float ExpectedZaccel = 98.0;
float minZaccel;
float maxZaccel;
float Zspd = 0;
int Xaccel;
int ExpectedXaccel = 98;
int Xspd = 0;
int Yaccel;
int ExpectedYaccel = 98;
int Yspd = 0;


int distance = 10;
int spd = 1000;
int spdset= 1000;
int spd1= 1000;
int spd2= 1000;
int spd3= 1000;
int spd4= 1000;
int spd1set= 1000;
int spd2set= 1000;
int spd3set= 1000;
int spd4set= 1000;
int Y= 0;
int X= 0;
int Z= 0;
bool newZ= false;
int PreviousY= 0;
int PreviousX= 0;
int PreviousZ= 0;
Timer motiontimer;
int timchange;
float speedscale ; 


    long map(long x, long in_min, long in_max, long out_min, long out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;}
    
    float calculatestabilizer(struct stabilizer s){
    Serror =   abs(s.setpoint- s.input);
    if(Serror != 0){
    //pc.printf(" SE = %f  ",Serror);
    float Perror = Serror * s.Kp;
    //pc.printf("PE  =%f \n",Perror);
    
    float Ierror =  s.Ki*(s.previouserror+Serror);
   // pc.printf(" IE=  %f",Ierror);
    float Derror =   (s.previouserror - Serror );
       
    //pc.printf("DE=  %f, \n",Derror);
    //s.previouserror = s.input - s.setpoint; ;
    s.output= Perror + Ierror +Derror;
    
    if(s.output > 500 ){s.output = 500;}
    if(s.output < 0 ){s.output = 0;}
    
        
    
       // pc.printf(" %f  \n" , s.output);
    return s.output;
    
    }}
    
    
void updateMotion()
{
    // Zaccel is in 10*cm per second per second 
    timchange= motiontimer.read_ms(); // get time in microseconds
    speedscale = 1000/(timchange);
    motiontimer.reset(); // reset timer
    
     //  Zaccel in metres per second 
    Zspd = Zspd + (Zaccel*timchange*speedscale); // Zspd is in metres per second
    
    
    //Zspd = Zspd / 10.0; //Zspd ios in mm/microsecond
    
    //pc.printf("%f %f %d\n",Zaccel, Zspd, timchange);
    
    
    
    }