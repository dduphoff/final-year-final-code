#include "mbed.h"
#include "MPU6050.h"
#include "functions.h"

#include "MPU6050.h"

//Serial ESP8266(PB_3, PB_4);
float zero = 1;



bool running = true;

int iSer=0; //i 
Ticker update;
Ticker pid;
Ticker stopper;
bool newcmd = false;
int i = 0;
bool newMpuData = false;
bool newspd = false;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void stop()
{
      
      running = false ;
      }
      
  void pidupdate(void){
    
      
    
    newMpuData = true;
    }
    
       
    
    



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void SensorUpdate(void)


{
   newspd = true;
    
  //newMpuData = true;
    
       
        
       
        
    }
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void espserial(void)
{
    char c;
    if(esp8266.readable())
         {
            c = esp8266.getc();
            //pc.printf("%c", c);
            
            //pc.printf(" before adding to array");
            cmd[i]= c;
            //pc.printf(" after adding to array");
            i= i+1;
            
             }
          if(c=='%'){
              cmd[i-1]= '\0';
             // pc.printf("%s \n", cmd);
          cmd_exe();
          i=0;
          newcmd= true;
        
          
          
        }
    
   } 
 

int main() {
    
  // ESC1.period(1);
   // spd = 1000;
    // ESC1.pulsewidth_us(spd); // write new speeds to motors
     //ESC2.pulsewidth_us(spd);
     //ESC3.pulsewidth_us(spd);
     //ESC4.pulsewidth_us(spd);
    // ESC1.write(1.0f); // write new speeds to motors
     //ESC2.write(1.0f);
    // ESC3.write(1.0f);
     //ESC4.write(1.0f);
   //  wait(2);
    //spd = 2000;
   // ESC1.pulsewidth_us(spd); // write new speeds to motors
    // ESC2.pulsewidth_us(spd);
     //ESC3.pulsewidth_us(spd);
    // ESC4.pulsewidth_us(spd);
   // ESC1.write(0.0f); // write new speeds to motors
     //ESC2.write(0.0f);
     //ESC3.write(0.0f);
     //ESC4.write(0.0f);
   
    
    
    update.attach(SensorUpdate, 0.05); // smooth speed changes 
    pid.attach(pidupdate,0.01);
    
    
    
   // update.attach(&SensorUpdate, 0.2);
    //Serial
    spdUpdate();
   motiontimer.start();
    ////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
      struct stabilizer pitchpid; // initialize pitch pid
    pitchpid.setpoint = (0);
    pitchpid.input = pitch;
    pitchpid.output = pitchmod  ;
    pitchpid.Kp = PKp;
    pitchpid.Ki = PKi;
    pitchpid.Kd = PKd;
    pitchpid.previouserror = 0; 
    struct stabilizer rollpid; // initialize roll pid
    rollpid.setpoint = (0);
    rollpid.input = roll;
    rollpid.output = rollmod  ;
    rollpid.Kp = RKp;
    rollpid.Ki = RKi;
    rollpid.Kd = RKd;
    rollpid.previouserror = 0; 
    struct stabilizer yawpid;
    yawpid.setpoint = 0;
    yawpid.input= yaw;
    yawpid.output = yawmod;
    yawpid.Kp = YKp;
    yawpid.Ki = YKi;
    yawpid.Kd = YKd;
    
    pc.baud(256000);
    ////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    MPU.whoAmI();///MPU6050 INIT
    MPU.init();///
    //wait(4);///
    MPU.calibrate(accelBias,gyroBias);///
    ////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    for (int i = 0 ; i<10 ; i ++)
    {
        MPU.readAccelData(accelData);
        wait(0.1);
        
        }
        gravmag = (accelData[2]*accelData[2])+(accelData[1]*accelData[1])+(accelData[0]*accelData[0]);
        gravmag = sqrt(gravmag);
    pc.printf("gravmag = %f \n", gravmag);
    calculateangle();
    rollpid.setpoint = roll;
    pitchpid.setpoint = pitch;
    pc.printf(" roll sepoint = %f pitch setpoint = %f \n",rollpid.setpoint , pitchpid.setpoint);
    ////////////////////////////////////////////////////////////////////////////
    firstZaccel = accelData[2];
    oldtx.mode(PullNone);
    oldrx.mode(PullNone);
    //Esp_Serial.start(espserial);
    //wait_us(200);// trying to get timer to allow for mpu to write data and speed calculations from data
   //pitchpid.setSetPoint(0);
  // ESC1.pulsewidth_us(1000);
   //ESC2.pulsewidth_us(1000);
   //ESC3.pulsewidth_us(1000);
  // ESC4.pulsewidth_us(1000);
   rollset = rollpid.setpoint;
   pitchset= pitchpid.setpoint;
   yawset = yawpid.setpoint;
   
  yawset = 0;
  pitchP =pitchpid.Kp ;
     pitchI =pitchpid.Ki ;
    pitchD =pitchpid.Kd  ;
     rollP =rollpid.Kp ;
    rollI =rollpid.Ki  ;
    rollD =rollpid.Kd  ;
     yawP= yawpid.Kp ;
     yawI= yawpid.Ki ;
    yawD =yawpid.Kd ;
  wait(3);
   esp8266.attach(&espserial);
   
  // stopper.attach(&stop, 15);
    while(1) {

    
    while(running == true){
    MPU.readAccelData(accelData);
    
    MPU.readGyroData(gyroData);

   
      
      
    calculateangle();
    /////////////
    pitchpid.Kp = pitchP;
    pitchpid.Ki = pitchI;
    pitchpid.Kd = pitchD;
    rollpid.Kp = rollP;
    rollpid.Ki = rollI;
    rollpid.Kd = rollD;
    yawpid.Kp = yawP;
    yawpid.Ki = yawI;
    yawpid.Kd = yawD;
    pitchpid.setpoint = pitchset;
    rollpid.setpoint = rollset;
    //pc.printf("%d %d %d %d     roll = %f   pitch = %f\n",spd1, spd2, spd3, spd4, roll, pitch); 
   if(newcmd==false){
   pc.printf(
    "  ____          ____   \n"
   "  /    \         /    \  \n "
    "( %d )      ( %d )  \n "      
    " \\____/        \\____/   \n "       
   "      \\\        //        \n "       
    "       \\\      //  pitch=%f      \n "       
    "        \\\    //   roll=%f  \n "       
    "        |-----|  change in yaw= %f  \n "       
    "        |     |  pitchset= %d\n "       
    "        |_____| rollset=%d\n "       
    "        //    \\        \n "       
    "       //      \\       \n "       
    "   ___//        \\__   \n"
    "   /    \         /    \  \n "       
    " ( %d )      ( %d )  \n "   
    "  \\____/        \\____/   \n "   ,spd1, spd2 , pitch, roll , yaw, pitchset, rollset, spd3, spd4      );
    }
    else{
         
         newcmd =false;
         pc.printf(
         
    "  ____          ____   \n"
    "  /    \         /    \  \n "
    "( %d )      ( %d )  \n "      
    " \\____/        \\____/   \n "       
    "      \\\        //        \n "       
    "       \\\      //  pitch=%f      \n "       
  "        \\\    //   roll=%f  \n "       
    "        |-----|  change in yaw= %f  \n "       
    "        |     |  pitchset= %d\n "       
   "        |_____| rollset=%d\n "       
    "        //    \\   %s     \n "       
    "       //      \\       \n "       
    "   ___//        \\__   \n"
    "   /    \         /    \  \n "       
    " ( %d )      ( %d )  \n "   
 "  \\____/        \\____/   \n "   ,spd1, spd2 , pitch, roll , yaw, pitchset, rollset,cmd, spd3, spd4      );
    
        }
    wait(.2);
    yawpid.setpoint = yawset;
    pitchpid.input = pitch;
    rollpid.input = roll;
    yawpid.input = yaw;
    pitchmod = calculatestabilizer(pitchpid);
    //pc.printf("pitch = %f", pitchmod);
    pitchpid.previouserror = Serror;
    //pc.printf("<-- pitch    roll -->" );
    Serror = 0;
    rollmod = calculatestabilizer(rollpid);
    rollpid.previouserror = Serror;
    yawmod = calculatestabilizer(yawpid);
    //pc.printf(" yaw = %f\n", yawmod);
    
      
     spdUpdate();
     
     int Spdchange = (((spd1set + spd2set + spd3set +spd4set)/4) - ((spd1+spd2+spd3+spd4)/4)/5);
             // ESC1.write(0.5); 
              // pc.printf("%d \n",spd1);
               
             
   
           }
       
      
      }
      
      
      
      
      
      if (spd>=1000){
       pc.printf("stopped"); 
        wait(0.2);
        spd1 = spd1 - 25;
        
      spd2= spd2 - 25;
      spd3=spd3 - 25;
      spd4 = spd4 - 25;
            ESC1.pulsewidth_us(spd1);
      ESC2.pulsewidth_us(spd2);
      ESC3.pulsewidth_us(spd3);
      ESC4.pulsewidth_us(spd4);
        }
}
  



